package com.example.optimisation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private int count = 0;
    protected TextView txtnb, txtValue, txtResult;

    private int pourcentageUpp = 10;

    protected Button btn;

    protected EditText editTxt;

    protected ProgressBar maprobar;

    protected ArrayList tab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtnb = findViewById(R.id.txtnb);
        txtValue = findViewById(R.id.txtValue);
        txtResult = findViewById(R.id.txtResult);
        editTxt = findViewById(R.id.editTxt);
        btn = findViewById(R.id.btn);
        maprobar = findViewById(R.id.maprobar);

        double numberRand = Math.random() * 100 + 1;

        int randInteger = (int) numberRand;

        int numberInit = randInteger;



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String valid = editTxt.getText().toString().trim();
                int valid2;
                if (valid.equals("")) {
                    Context context = getApplicationContext();
                    int duration = Toast.LENGTH_LONG;

                    Toast toaster = Toast.makeText(context, "Vous n'avez pas entrez de valeur", duration);
                    toaster.show();
                    return;
                }
                valid2 = Integer.parseInt(valid);


                if (valid2 == numberInit) {
                    txtValue.setText("Vous avez réussi !");
                } else if (valid2 > numberInit) {
                    txtValue.setText("Vous avez un nombre supérieur");
                    progressBar();
                    count++;
                } else {
                    txtValue.setText("Vous avez un nombre inférieur");
                    progressBar();
                    count++;
                }
            }
        });

    }
    protected void progressBar() {
        maprobar.incrementProgressBy(pourcentageUpp);
        if (pourcentageUpp == 100){
            txtResult.setText("Vous avez perdu");
            return;
        }
    }

    protected  void  historique() {
        String historique =
    }
}




